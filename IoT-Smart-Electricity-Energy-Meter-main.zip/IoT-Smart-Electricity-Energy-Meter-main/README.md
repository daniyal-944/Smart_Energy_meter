# IoT-Smart-Electricity-Energy-Meter
We will build an IoT-based Smart Electricity Energy Meter using ESP32 and the newly updated Blynk 2.0 application.
